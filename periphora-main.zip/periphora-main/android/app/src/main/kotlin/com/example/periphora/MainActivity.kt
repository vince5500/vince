package com.example.periphora

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
